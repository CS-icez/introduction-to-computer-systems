/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_462(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_366(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_367(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_176(unsigned x)
{
    return x + 3347646521U;
}

unsigned getval_256()
{
    return 3284633932U;
}

unsigned addval_434(unsigned x)
{
    return x + 2420683137U;
}

void setval_289(unsigned *p)
{
    *p = 2421726072U;
}

unsigned getval_415()
{
    return 4140259459U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_453(unsigned *p)
{
    *p = 3531917961U;
}

void setval_115(unsigned *p)
{
    *p = 3531917977U;
}

void setval_277(unsigned *p)
{
    *p = 3523789209U;
}

unsigned addval_185(unsigned x)
{
    return x + 3531921097U;
}

void setval_395(unsigned *p)
{
    *p = 3676357001U;
}

unsigned getval_328()
{
    return 3229931137U;
}

void setval_167(unsigned *p)
{
    *p = 3252717896U;
}

unsigned addval_264(unsigned x)
{
    return x + 3375945369U;
}

void setval_339(unsigned *p)
{
    *p = 3525362121U;
}

unsigned getval_112()
{
    return 3677407881U;
}

unsigned addval_231(unsigned x)
{
    return x + 3525362073U;
}

unsigned getval_173()
{
    return 3286288712U;
}

unsigned addval_215(unsigned x)
{
    return x + 2430634056U;
}

unsigned getval_139()
{
    return 3674786445U;
}

unsigned getval_145()
{
    return 3285617068U;
}

void setval_372(unsigned *p)
{
    *p = 3285618044U;
}

unsigned getval_464()
{
    return 3286272328U;
}

unsigned getval_465()
{
    return 3767094496U;
}

unsigned getval_186()
{
    return 3224947209U;
}

unsigned getval_178()
{
    return 2425405825U;
}

void setval_420(unsigned *p)
{
    *p = 3523791561U;
}

unsigned getval_121()
{
    return 2425667977U;
}

unsigned addval_239(unsigned x)
{
    return x + 3375939977U;
}

unsigned addval_416(unsigned x)
{
    return x + 3286272328U;
}

void setval_457(unsigned *p)
{
    *p = 3281049225U;
}

unsigned addval_417(unsigned x)
{
    return x + 2497743176U;
}

unsigned addval_132(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_194(unsigned x)
{
    return x + 3380920715U;
}

void setval_225(unsigned *p)
{
    *p = 3525364361U;
}

void setval_271(unsigned *p)
{
    *p = 2425411273U;
}

unsigned getval_486()
{
    return 2425673353U;
}

void setval_151(unsigned *p)
{
    *p = 3682126473U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
